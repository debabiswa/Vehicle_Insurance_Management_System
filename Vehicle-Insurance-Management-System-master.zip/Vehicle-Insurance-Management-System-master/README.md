# Vehicle-Insurance-Management-System
A simple python application for managing vehicle insurance
